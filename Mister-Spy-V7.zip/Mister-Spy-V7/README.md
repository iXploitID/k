# MisterSpy-V7<br>
My Last Bot V7 <br>
install python 2.7.14<br>
link :<br>
https://www.python.org/downloads/release/python-2714/<br>
Open Cmd write :<br> 
cd C:\Python27<br>
then<br>
pip install requests<br>
then<br>
pip install colorama<br>
then<br>
any problem u can contact me in icq or facebook :<br><br>
https://www.facebook.com/007MrSpy<br>
icq : 712083179<br>
\n Tuto<br>
https://www.youtube.com/watch?v=pzsIsa6pvPw<br><br>

          " " " " " " " " " " " " " " " " " " " "  "
          "                  ,__,                  "
          "                  (oo)____              "
          "                  (__)    )\            "
          "                     ||--|| *  V7       "
          "                                        "
          " " " " " " " " " " " " " " " " " " " "  "
