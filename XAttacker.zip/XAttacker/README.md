<h1>XAttacker Tool</h1>
<p><a href="https://github.com/Moham3dRiahi/XAttacker"><img src="https://img.shields.io/badge/XAttacker-2.5-brightgreen.svg" alt="Version" data-canonical-src="https://img.shields.io/badge/XAttacker-2.5-brightgreen.svg?maxAge=259200" style="max-width:100%;"></a>
<a href="https://github.com/Moham3dRiahi/XAttacker"><img src="https://img.shields.io/badge/Release-Stable-orange.svg" alt="Stage" data-canonical-src="https://img.shields.io/badge/Release-Stable-orange.svg" style="max-width:100%;"></a>
<a href="https://github.com/Moham3dRiahi/XAttacker"><img src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" alt="Build" data-canonical-src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" style="max-width:100%;"></a></p>
<p>X Attacker Tool ☣ Website Vulnerability Scanner & Auto Exploiter<br>You can use this tool to check the security by finding the vulnerability in your website or you can use this tool to Get Shells | Sends | Deface | cPanels | Databases</p>

<h2>X Attacker</h2>

X Attacker Tool ☣ Website Vulnerability Scanner & Auto Exploiter
<img src="https://i.imgur.com/DxZyQit.jpg" data-canonical-src="https://i.imgur.com/DxZyQit.jpg" style="max-width:100%;">

<b>[+] Auto Cms Detect<b>

<b>[1] WordPress :<b><br>

[+] Adblock Blocker  <br>
[+] WP All Import <br>
[+] Blaze <br>
[+] Catpro <br>
[+] Cherry Plugin  
[+] Download Manager  
[+] Formcraft 
<br>[+] levoslideshow 
<br>[+] Power Zoomer  
[+] Gravity Forms  
[+] Revslider Upload Shell  
[+] Revslider Dafece Ajax  
[+] Revslider Get Config  
[+] Showbiz  
[+] Simple Ads Manager  
[+] Slide Show Pro  
[+] WP Mobile Detector  
[+] Wysija  
[+] InBoundio Marketing  
[+] dzs-zoomsounds  
[+] Reflex Gallery  
[+] Creative Contact Form  
[+] Work The Flow File Upload  
[+] WP Job Manger  
[+] PHP Event Calendar  
[+] Synoptic  
[+] Wp Shop  
[+] Content Injection 
<br>[+] Cubed Theme  `NEW`
<br>[+] Rightnow Theme  `NEW`
<br>[+] Konzept  `NEW`
<br>[+] Omni Secure Files  `NEW`
<br>[+] Pitchprint  `NEW`
<br>[+] Satoshi  `NEW`
<br>[+] Pinboard  `NEW`
<br>[+] Barclaycart  `NEW`

<b>[2] Joomla<br>

[+] Com Jce  
[+] Com Media  
[+] Com Jdownloads  
[+] Com Fabrik  
[+] Com Jdownloads Index  
[+] Com Foxcontact  
[+] Com Ads Manager  
[+] Com Blog  
[+] Com Users  
[+] Com Weblinks<br>
[+] mod_simplefileupload 
<br>[+] Com Facileforms  `NEW`
<br>[+] Com Jwallpapers `NEW`
<br>[+] Com Extplorer `NEW`
<br>[+] Com Rokdownloads `NEW`
<br>[+] Com Sexycontactform `NEW`
<br>[+] Com Jbcatalog `NEW`

<b>[3] DruPal<br> 

[+] Add Admin
<br>[+] Drupalgeddon `NEW`<br><br>
[4] PrestaShop<br>

[+] columnadverts  
[+] soopamobile  
[+] soopabanners  
[+] Vtermslideshow  
[+] simpleslideshow  
[+] productpageadverts  
[+] homepageadvertise  
[+] homepageadvertise2  
[+] jro_homepageadvertise  
[+] attributewizardpro  
[+] 1attributewizardpro  
[+] AttributewizardproOLD  
[+] attributewizardpro_x  
[+] advancedslider  
[+] cartabandonmentpro  
[+] cartabandonmentproOld  
[+] videostab  
[+] wg24themeadministration  
[+] fieldvmegamenu  
[+] wdoptionpanel  
[+] pk_flexmenu  
[+] pk_vertflexmenu  
[+] nvn_export_orders  
[+] megamenu  
[+] tdpsthemeoptionpanel  
[+] psmodthemeoptionpanel  
[+] masseditproduct
<br>[+] blocktestimonial `NEW`<br>

<b>[5] Lokomedia<br>

SQL injection

<h2>Video</h2>
<a href="https://www.youtube.com/watch?v=EgqTsrWt2VU"><img src="https://i.imgur.com/5B96biH.png" style="max-width:100%;"></a>

<h2>Usage</h2>

<table>
<thead>
<tr>
<th>Short Form</th>
<th>Long Form</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>-l</td>
<td>--list</td>
<td>websites list</td>
</tr>
</tbody></table>
<h2>Example</h2>
<p>if you have list websites run tool with this command line<p>
<code>perl XAttacker.pl -l list.txt</code>
<p>if you don't have list websites run the tool with this command<p>
<code>perl XAttacker.pl</code>

<hr> 
<h2>BUG ?</h2>
<ul><li>Submit new issue</li></ul><hr>
<h2>My New Private Tool</h2>
<li>https://www.youtube.com/watch?v=-8yLE5gxxKU</li>
<hr>
<h2>📧 Contact</h2>
<li>You Want Ask About All My Tools Or Buy Tools/Exploits Private Add Me On ICQ : 712653075</li>
<hr>

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)

```bash
git clone https://github.com/Moham3dRiahi/XAttacker.git
cd XAttacker
perl XAttacker.pl
```

Follow This Video [SSTec Tutorials](https://www.youtube.com/watch?v=ckHIm4-_Zbs)

## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
git clone https://github.com/Moham3dRiahi/XAttacker.git
cd XAttacker
chmod +x termux-install.sh
bash termux-install.sh
```

Follow This Video [Psyco Tutorials](https://www.youtube.com/watch?v=3QezrdBW1D8)

## Installation [Windows ](https://wikipedia.org/wiki/Microsoft_Windows)[![alt tag](http://icons.iconarchive.com/icons/tatice/cristal-intense/32/Windows-icon.png)](https://fr.wikipedia.org/wiki/Microsoft_Windows)
```bash
Download Perl
Download XAttacker
Extract XAttacker into Desktop
Open CMD and type the following commands:
cd Desktop/XAttacker-master/
perl XAttacker.pl
```
<h2>Version</h2>
<strong>Current version is 2.5</strong>
<strong>What's New </strong>
<br>• blocktestimonial Exploit
<br>• Cubed Theme Exploit
<br>• Rightnow Theme Exploit
<br>• Konzept Exploit
<br>• Omni Secure Files Exploit
<br>• Pitchprint Exploit
<br>• Satoshi Exploit
<br>• Pinboard Exploit
<br>• Barclaycart Exploit
<br>• Com Facileforms Exploit
<br>• Com Jwallpapers Exploit
<br>• Com Extplorer Exploit
<br>• Com Rokdownloads Exploit
<br>• Com Sexycontactform Exploit
<br>• Com Jbcatalog Exploit
<br>• Com Blog Exploit
<br>• Com Foxcontact Exploit
<br>• Drupal Geddon Exploit
<br>• Speed up
<br>• Bug fixes

<br>[+] Konzept  `NEW`
<br>[+] Omni Secure Files  `NEW`
<br>[+] Pitchprint  `NEW`
<br>[+] Satoshi  `NEW`
<br>[+] Pinboard  `NEW`
<br>[+] Barclaycart  `NEW`

<b>[2] Joomla<br>

[+] Com Jce  
[+] Com Media  
[+] Com Jdownloads  
[+] Com Fabrik  
[+] Com Jdownloads Index  
[+] Com Foxcontact  
[+] Com Ads Manager  
[+] Com Blog  
[+] Com Users  
[+] Com Weblinks<br>
[+] mod_simplefileupload 
<br>[+] Com Facileforms  `NEW`
<br>[+] Com Jwallpapers `NEW`
<br>[+] Com Extplorer `NEW`
<br>[+] Com Rokdownloads `NEW`
<br>[+] Com Sexycontactform `NEW`
<br>[+] Com Jbcatalog `NEW`

<b>[3] DruPal<br> 

[+] Add Admin
<br>[+] Drupalgeddon `NEW`<br><br>
[4] PrestaShop<br>

[+] columnadverts  
[+] soopamobile  
[+] soopabanners  
[+] Vtermslideshow  
[+] simpleslideshow  
[+] productpageadverts  
[+] homepageadvertise  
[+] homepageadvertise2  
[+] jro_homepageadvertise  
[+] attributewizardpro  
[+] 1attributewizardpro  
[+] AttributewizardproOLD  
[+] attributewizardpro_x  
[+] advancedslider  
[+] cartabandonmentpro  
[+] cartabandonmentproOld  
[+] videostab  
[+] wg24themeadministration  
[+] fieldvmegamenu  
[+] wdoptionpanel  
[+] pk_flexmenu  
[+] pk_vertflexmenu  
[+] nvn_export_orders  
[+] megamenu  
[+] tdpsthemeoptionpanel  
[+] psmodthemeoptionpanel  
[+] masseditproduct
<br>[+] blocktestimonial `NEW`<br>

<b>[5] Lokomedia<br>

SQL injection

<h2>Video</h2>
<a href="https://www.youtube.com/watch?v=EgqTsrWt2VU"><img src="https://i.imgur.com/5B96biH.png" style="max-width:100%;"></a>

<h2>Usage</h2>

<table>
<thead>
<tr>
<th>Short Form</th>
<th>Long Form</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>-l</td>
<td>--list</td>
<td>websites list</td>
</tr>
</tbody></table>
<h2>Example</h2>
<p>if you have list websites run tool with this command line<p>
<code>perl XAttacker.pl -l list.txt</code>
<p>if you don't have list websites run the tool with this command<p>
<code>perl XAttacker.pl</code>

<hr>
<h2>BUG ?</h2>
<ul><li>Submit new issue</li></ul><hr>
<h2>📧 Contact</h2>
<li>You Want Ask About All My Tools Or Buy Tools/Exploits Private Add Me On ICQ : 712653075</li>
<hr>

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)

```bash
git clone https://github.com/Moham3dRiahi/XAttacker.git
cd XAttacker
perl XAttacker.pl
```

Follow This Video [SSTec Tutorials](https://www.youtube.com/watch?v=ckHIm4-_Zbs)

## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
git clone https://github.com/Moham3dRiahi/XAttacker.git
cd XAttacker
chmod +x termux-install.sh
bash termux-install.sh
```

Follow This Video [Psyco Tutorials](https://www.youtube.com/watch?v=3QezrdBW1D8)

## Installation [Windows ](https://wikipedia.org/wiki/Microsoft_Windows)[![alt tag](http://icons.iconarchive.com/icons/tatice/cristal-intense/32/Windows-icon.png)](https://fr.wikipedia.org/wiki/Microsoft_Windows)
```bash
Download Perl
Download XAttacker
Extract XAttacker into Desktop
Open CMD and type the following commands:
cd Desktop/XAttacker-master/
perl XAttacker.pl
```
<h2>Version</h2>
<strong>Current version is 2.5</strong>
<strong>What's New </strong>
<br>• blocktestimonial Exploit
<br>• Cubed Theme Exploit
<br>• Rightnow Theme Exploit
<br>• Konzept Exploit
<br>• Omni Secure Files Exploit
<br>• Pitchprint Exploit
<br>• Satoshi Exploit
<br>• Pinboard Exploit
<br>• Barclaycart Exploit
<br>• Com Facileforms Exploit
<br>• Com Jwallpapers Exploit
<br>• Com Extplorer Exploit
<br>• Com Rokdownloads Exploit
<br>• Com Sexycontactform Exploit
<br>• Com Jbcatalog Exploit
<br>• Com Blog Exploit
<br>• Com Foxcontact Exploit
<br>• Drupal Geddon Exploit
<br>• Speed up
<br>• Bug fixes
