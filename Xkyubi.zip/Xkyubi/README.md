# xkyuby

All IN One Tool : exploiters/checker/grabbers/senders/scanners
```
  __    __  __                            __
  /  |  /  |/  |                          /  |
  $$ |  $$ |$$ |   __  __    __  __    __ $$ |____   __    __
  $$  \/$$/ $$ |  /  |/  |  /  |/  |  /  |$$      \ /  |  /  |
   $$  $$<  $$ |_/$$/ $$ |  $$ |$$ |  $$ |$$$$$$$  |$$ |  $$ |
    $$$$  \ $$   $$<  $$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |  $$ |
   $$ /$$  |$$$$$$  \ $$ \__$$ |$$ \__$$ |$$ |__$$ |$$ \__$$ |
  $$ |  $$ |$$ | $$  |$$    $$ |$$    $$/ $$    $$/ $$    $$ |
  $$/   $$/ $$/   $$/  $$$$$$$ | $$$$$$/  $$$$$$$/   $$$$$$$ |
                      /  \__$$ |                    /  \__$$ |
                    $$    $$/                     $$    $$/
                     $$$$$$/                       $$$$$$/
        *--- Welc0me To xkyuby (X4priv8 V3) ---*
        Developed By + Escanor(Oussama Ben Mahmoud)
                 + ARON-TN(Amir Othman)
                 + M4rkWalker(Z4ck)
>--- We do not take any responsibility for any ilegal act ---<
[01] Filtre Mail (+25)         [02] Hash-Identify
[03] SMTP Sender               [04] Sarahah Sender
[05] Saraha.online Sender      [06] XSmash FB ToolBox
[07] Combo&List MultiEditor    [08] Username Checker
[09] CC Generator              [10] Key Generator
[11] Facebook Bruter           [12] Netflix Checker
[13] Instagram Checker         [14] HMA Checker(combo)
[15] Proxy Grabber             [16] Proxy Checker
[17] SMTP checker & Bruter     [18] Web Scanner & Exploiter(+700)
[19] WPScanner                 [20] JoomScanner
[21] Dorker (with list)        [22] SQLI Scanner
[23] Config Grabber            [24] Email Crawler
[25] AdminPanel Finder&Bruter  [26] Config Finder
[27] TENA (FastsiteGrabber)    [28] Zone-h Grabber
[29] Zone-h Poster             [30] Mirror-h Grabber
[31] Mirror-h Poster           [32] Python Modules Fixer
[33] Wso Shell Bruter          [34] Shell Finder
[35] Config2AdminDB            [36] Get Config Deja Grabbed
[00] About && Contact Coderz
```
**Contact**
<br>
<a href="https://facebook.com/meliodas404">Facebook</a><br>
<a href="mailto:tsuminor@gmail.com">Mail</a><br>
<a href="https://www.youtube.com/channel/UCiWDN1Awn1ckZrFAodzMvDA">Youtube</a><br>
